<?php

header("Access-Control-Allow-Origin: *");
include "buffer_test.php";

/*
$servername = "localhost";
$username = "balajiceg";
$password = "Balaji07";
$database="bike_pool";


	$conn = new mysqli($servername, $username, $password, $database);
	if ($conn->connect_errno) {
		$return["error"]=0;
		$return["error_msg"]="Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error;
		die(json_encode($return));
	}
	

	
	$sql = "insert into users (name,mobile) values('kaghshgas','333432444652');";
	$result = $conn->query($sql);
	
	
		 $a=$conn->errno;
		 print_r($a);
	if($result==true)
	print_r($result);
	if($result==false)
	print_r("aljsdhshd");
	$conn->close();*/

	
	
	echo(st_dwithin_pts("POINT(0 0)","POINT(20 0)",20));
	
	

	


 ?>


