<?php



header("Access-Control-Allow-Origin: *");

include "buffer_test.php";

spl_autoload_register(function ($class_name) {

    include $class_name . '.php';

});

$wgs_utm=new GpointConverter();
$buff_dis_ends=200;
$target_version=2;

$servername = "balaji.apps19.com";
$username = "a7506702_idiot";
$password = "uchiachitachi1,.";
$database="a7506702_idiot";
$return=array();
$return["error"]=0;
$return["error_msg"]="none";

if(isset($_POST["req"]))
{
	$conn = new mysqli($servername, $username, $password, $database);
	if ($conn->connect_errno) {
		$return["error"]=5;
		$return["error_msg"]="Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error;
		die(json_encode($return));
	}

	/////////////////request 0
	if($_POST["req"]==0)
	{
		$sql = "select name,id from users where mobile=".$_POST['mobile'].";";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		$row = $result->fetch_row();
		$return['name']=$row[0];
		$return['id']=$row[1];
		} 

		else 
		{
			$return["error"]=2;
			$return["error_msg"]="no result from query";
		}
		$conn->close();
	}
	
	
	//////////////request 1
	else if($_POST["req"]==1)
	{
		$sql = "insert into users (name,mobile) values('".$_POST['name']."','".$_POST['mobile']."');";
		$result = $conn->query($sql);
		if($result==false)
		{
			if($conn->errno==1062)
			{
				$return["error"]=3;
				$return["error_msg"]="duplicate entry";	
			}
			else
			{
				$return["error"]=4;
				$return["error_msg"]="Query Fail:".$conn->error;	
			}
		}
		else
		{
			$sql = "select id,points from users where mobile='".$_POST['mobile']."';";
			$result = $conn->query($sql);
			if($result==false)
			{
				$return["error"]=4;
				$return["error_msg"]="Query Fail:".$conn->error;
			}
			if ($result->num_rows > 0) {
			$row = $result->fetch_row();
			$return['id']=$row[0];
			$return['points']=$row[1];
			} 
			else 
			{
				$return["error"]=2;
				$return["error_msg"]="no result from query";
			}
		}
		
		$conn->close();
	}
	
	/////request 2
	else if($_POST["req"]==2)
	{
		$start_lat=$_POST["start_lat"];
		$start_lng=$_POST["start_lng"];
		$dest_lat=$_POST["dest_lat"];
		$dest_lng=$_POST["dest_lng"];
		
		$temp=$wgs_utm->convertLatLngToUtm($start_lat,$start_lng);
		$start_lat_utm=$temp[1];
		$start_lng_utm=$temp[0];
		
		$temp=$wgs_utm->convertLatLngToUtm($dest_lat,$dest_lng);
		$dest_lat_utm=$temp[1];
		$dest_lng_utm=$temp[0];
			
		$sql = "update users set t_start=PointFromText('POINT($start_lng $start_lat)',0),
								 t_start_utm=PointFromText('POINT($start_lng_utm $start_lat_utm)',0),
								 t_dest=PointFromText('POINT($dest_lng $dest_lat)',0),
								 t_dest_utm=PointFromText('POINT($dest_lng_utm $dest_lat_utm)',0),
								 t_start_time=".$_POST['start_time'].",
								 t_end_time=".$_POST['end_time']."
				where id=".$_POST['id'].";";
		
		$result = $conn->query($sql);
		if($result==false)
		{
			$return["error"]=4;
			$return["error_msg"]="Query Fail:".$conn->error;	
		}
		else
		{
			$return["result"]="write_success";
		}
		
	}
	
	/////request 3
	else if($_POST["req"]==3)
	{
		$start_lat=$_POST["start_lat"];
		$start_lng=$_POST["start_lng"];
		$dest_lat=$_POST["dest_lat"];
		$dest_lng=$_POST["dest_lng"];

		$temp=$wgs_utm->convertLatLngToUtm($start_lat,$start_lng);
		$start_lat_utm=$temp[1];
		$start_lng_utm=$temp[0];
		
		$temp=$wgs_utm->convertLatLngToUtm($dest_lat,$dest_lng);
		$dest_lat_utm=$temp[1];
		$dest_lng_utm=$temp[0];
		
		$r=json_decode($_POST["path"]);
		$latlang_arr=array();
		
		foreach($r as $k => $v)
		{
			foreach($v as $latlang)
			{
				$temp_arr=array();
				foreach($latlang as $key => $value)
				{
					if($key=="lat")
						$temp_arr["lat"]=$value;
					else if($key=="lng")
						$temp_arr["lng"]=$value;
				}
				array_push($latlang_arr,$temp_arr);
			}
		}
		
		$latlang_arr_utm=array();
		foreach($latlang_arr as $latlng)
		{
			$temp=$wgs_utm->convertLatLngToUtm($latlng['lat'],$latlng['lng']);
			array_push($latlang_arr_utm,array("lat"=>$temp[1],"lng"=>$temp[0]));
		}
		
		$o_path_utm="";
		$o_path_wgs="";
		for($i=0;$i<count($latlang_arr);$i++)
		{
			$o_path_utm=$o_path_utm.$latlang_arr_utm[$i]['lng']." ".$latlang_arr_utm[$i]['lat'].",";
			$o_path_wgs=$o_path_wgs.$latlang_arr[$i]['lng']." ".$latlang_arr[$i]['lat'].",";
		}
		$o_path_utm=substr($o_path_utm, 0, -1);
		$o_path_wgs=substr($o_path_wgs, 0, -1);
		
		$sql = "update users set o_start=PointFromText('POINT($start_lng $start_lat)',0),
								 o_start_utm=PointFromText('POINT($start_lng_utm $start_lat_utm)',0),
								 o_dest=PointFromText('POINT($dest_lng $dest_lat)',0),
								 o_dest_utm=PointFromText('POINT($dest_lng_utm $dest_lat_utm)',0),
								 o_start_time=".$_POST['start_time'].",
								 o_path_wgs=LineFromText('LINESTRING($o_path_wgs)',0),
								 o_path_utm=LineFromText('LINESTRING($o_path_utm)',0)
				where id=".$_POST['id'].";";
		
		$result = $conn->query($sql);
		if($result==false)
		{
			$return["error"]=4;
			$return["error_msg"]="Query Fail:".$conn->error;	
		}
		else
		{
			$return["result"]="write_success";
		}
	}

	/////request 4
	else if($_POST["req"]==4)
	{
		$dis=$_POST["dis"];
		$pdis=$GLOBALS['buff_dis_ends'];
		$sql = "select ASTEXT(t_start),ASTEXT(t_dest),ASTEXT(t_start_utm),ASTEXT(t_dest_utm),t_start_time,t_end_time from users where id=".$_POST['id'].";";
		$result = $conn->query($sql);
		if($result==false)
		{
			$return["error"]=4;
			$return["error_msg"]="Query Fail:".$conn->error;
		}
		if ($result->num_rows <= 0) {
			$return["error"]=2;
			$return["error_msg"]="no result from query";
		} 
		else 
		{	
			$row = $result->fetch_assoc();
			$pstart=$row["ASTEXT(t_start_utm)"];
			$pdest=$row["ASTEXT(t_dest_utm)"];
			
			$pstart_wgs=$row["ASTEXT(t_start)"];
			$pdest_wgs=$row["ASTEXT(t_dest)"];
			
			$start_time=floatval($row["t_start_time"])+$_POST["tzone"];
			$end_time=floatval($row["t_end_time"])+$_POST["tzone"];
			$start_time = DateTime::createFromFormat('H:i:s',date("H:i:s", $start_time/1000));
			$end_time = DateTime::createFromFormat('H:i:s',date("H:i:s", $end_time/1000));
			$return["start-time"]=$start_time->format('Y-m-d H:i:s');
			$return["end-time"]=$end_time->format('Y-m-d H:i:s');
			
			$sql = "select id,ASTEXT(o_path_utm),o_start_time,ASTEXT(o_start_utm),ASTEXT(o_dest_utm) from users where id!=".$_POST['id'].";";
			$result = $conn->query($sql);
			
				if($result==false)
				{
					$return["error"]=4;
					$return["error_msg"]="Query Fail:".$conn->error;
				}
				
				if ($result->num_rows <= 0) {
					$return["error"]=2;
					$return["error_msg"]="no result from query";
				} 
				else 
				{
					$selected="(";
					while($row = $result->fetch_assoc())
					{
						$path=$row["ASTEXT(o_path_utm)"];
						$usr_start=$row["ASTEXT(o_start_utm)"];
						$usr_dest=$row["ASTEXT(o_dest_utm)"];
						$id=$row["id"];
						$time=floatval($row["o_start_time"])+$_POST["tzone"];
						$time = DateTime::createFromFormat('H:i:s',date("H:i:s", $time/1000));
						$return["offer"]=$time->format('Y-m-d H:i:s');
						
						if($time>=$start_time&&$time<=$end_time&&(
							(st_dwithin($path,$pstart,$dis)&&st_dwithin($path,$pdest,$dis))
							||
							(st_dwithin_pts($pstart,$usr_start,$pdis)&&st_dwithin_pts($pdest,$usr_dest,$pdis))
							))
							$selected=$selected.$id.",";
						
					}
					$selected[strlen($selected)-1]=')';
					$return["data"]=$selected;
					if($selected==")")
					{
						$return["error"]=6;
						$return["error_msg"]="No matching users";
					}
					else
					{
						$sql = "select ID,NAME,MOBILE,O_START_TIME,ASTEXT(O_PATH_WGS) from users where id in ".$selected.";";
						$result = $conn->query($sql);
						if($result==false)
						{
							$return["error"]=4;
							$return["error_msg"]="Query Fail:".$conn->error;
						}
						else
						{
							$arr_rows=array();
							while($row = $result->fetch_assoc())
							{
								array_push($arr_rows,$row);
							}
							$return["result"]=$arr_rows;
							$return["start"]=$pstart_wgs;
							$return["dest"]=$pdest_wgs;
						}
					}
				}	
		}
	}	
	////request 5

	else if($_POST["req"]==5)

	{

		$dis=$_POST["dis"];

		$pdis=$GLOBALS['buff_dis_ends'];

		

		

		$sql = "select ASTEXT(o_path_utm),ASTEXT(o_path_wgs),o_start_time,ASTEXT(o_start_utm),ASTEXT(o_dest_utm) from users where id=".$_POST['id'].";";

		

		$result = $conn->query($sql);

		if($result==false)

		{

			$return["error"]=4;

			$return["error_msg"]="Query Fail:".$conn->error;

		}

		if ($result->num_rows <= 0) {

			$return["error"]=2;

			$return["error_msg"]="no result from query";

		} 

		else 

		{

			

			$row = $result->fetch_assoc();

			$path=$row["ASTEXT(o_path_utm)"];

			$path_wgs=$row["ASTEXT(o_path_wgs)"];

			$usr_start=$row["ASTEXT(o_start_utm)"];

			$usr_dest=$row["ASTEXT(o_dest_utm)"];

			

			$time=floatval($row["o_start_time"])+$_POST["tzone"];

			

			$time = DateTime::createFromFormat('H:i:s',date("H:i:s", $time/1000));

			

			$sql = "select id,ASTEXT(t_start_utm),ASTEXT(t_dest_utm),t_start_time,t_end_time from users where id!=".$_POST['id'].";";

			$result = $conn->query($sql);

			

				if($result==false)

				{

					$return["error"]=4;

					$return["error_msg"]="Query Fail:".$conn->error;

				}

				

				if ($result->num_rows <= 0) {

					$return["error"]=2;

					$return["error_msg"]="no result from query";

				} 

				else 

				{

					$selected="(";

					while($row = $result->fetch_assoc())

					{

						$pstart=$row["ASTEXT(t_start_utm)"];

						$pdest=$row["ASTEXT(t_dest_utm)"];

						$id=$row["id"];

						$start_time=floatval($row["t_start_time"])+$_POST["tzone"];

						$end_time=floatval($row["t_end_time"])+$_POST["tzone"];

						$start_time = DateTime::createFromFormat('H:i:s',date("H:i:s", $start_time/1000));

						$end_time = DateTime::createFromFormat('H:i:s',date("H:i:s", $end_time/1000));

						

						if($time>=$start_time&&$time<=$end_time&&(

							(st_dwithin($path,$pstart,$dis)&&st_dwithin($path,$pdest,$dis))

							||

							(st_dwithin_pts($pstart,$usr_start,$pdis)&&st_dwithin_pts($pdest,$usr_dest,$pdis))

							))

							$selected=$selected.$id.",";

						

					}

					$selected[strlen($selected)-1]=')';

					$return["data"]=$selected;

					if($selected==")")

					{

						$return["error"]=6;

						$return["error_msg"]="No matching users";

					}

					else

					{

						$sql = "select ID,NAME,MOBILE,T_START_TIME,T_END_TIME,ASTEXT(T_DEST),ASTEXT(T_START) from users where id in ".$selected.";";

						$result = $conn->query($sql);

						if($result==false)

						{

							$return["error"]=4;

							$return["error_msg"]="Query Fail:".$conn->error;

						}

						else

						{

							$arr_rows=array();

							while($row = $result->fetch_assoc())

							{

								array_push($arr_rows,$row);

							}

							$return["result"]=$arr_rows;

							$return["path"]=$path_wgs;

	

						}

					}

					

					

				}

			

			

		}

		

	}

	

	

	else if($_POST["req"]==6)

	{

		$lat=$_POST["lat"];

		$lng=$_POST["lng"];

		$id=$_POST["id"];

		$time=round(microtime(true) * 1000);

		

		$sql = "update users set location=PointFromText('POINT($lng $lat)',0),last_update=$time where id=".$_POST['id'].";";

		

		$result = $conn->query($sql);

		

		if($result==false)

		{

			$return["error"]=4;

			$return["error_msg"]="Query Fail:".$conn->error;	

		}

		else

		{

			$return["result"]="write_success";

		}

	}

	

	else if($_POST["req"]==7)

	{

		$id=$_POST["id"];

		$time=round(microtime(true) * 1000)-20000;//10 seconds for online

		

		$sql = "select ASTEXT(location) from users where last_update>=$time and id=".$_POST['id'].";";

		//$sql = "select ASTEXT(location) from users where id=".$_POST['id'].";";

		

		$result = $conn->query($sql);

		

		if($result==false)

		{

			$return["error"]=4;

			$return["error_msg"]="Query Fail:".$conn->error;	

		}

		if ($result->num_rows <= 0) {

			$return["error"]=2;

			$return["error_msg"]="no result from query";

		} 

		else

		{

			$row = $result->fetch_row();

			$return["location"]=$row[0];

		}
	}

	/////////////////request 8
	else if($_POST["req"]==8)
	{
		
		
			$sql = "select id,points,name,t_start_time,t_end_time,ASTEXT(t_start) as t_start,ASTEXT(t_dest) as t_dest,o_start_time,ASTEXT(o_start) as o_start,ASTEXT(o_dest) as o_dest,ASTEXT(o_path_wgs) as o_path_wgs from users where mobile='".$_POST['mobile']."';";
			$result = $conn->query($sql);
			if($result==false)
			{
				$return["error"]=4;
				$return["error_msg"]="Query Fail:".$conn->error;
			}
			if ($result->num_rows > 0) {
				$return['result']=1;
				$row = $result->fetch_assoc();
				$return['user']=$row;
			} 
			else 
			{
				$return["error"]=2;
				$return["error_msg"]="no result from query";
			}
			
			if($_POST["vercode"]<$GLOBALS['target_version'])
			{
				$return["error"]=7;
				$return["error_msg"]="Unsupported Version";
				$return["allow"]=1;
				$return["message"]="Please update your application";
			}
		
		
	}
	
	/////request 9
	else if($_POST["req"]==9)
	{
		$sql = "update users set t_start=null,
								 t_start_utm=null,
								 t_dest=null,
								 t_dest_utm=null,
								 t_start_time=null,
								 t_end_time=null
				where id=".$_POST['id'].";";
			
		$result = $conn->query($sql);
		if($result==false)
		{
			$return["error"]=4;
			$return["error_msg"]="Query Fail:".$conn->error;	
		}
		else
		{
			$return["result"]="update_success";
		}
		
	}
	
	/////request 10
	else if($_POST["req"]==10)
	{
			
		$sql = "update users set o_start=null,
								 o_start_utm=null,
								 o_dest=null,
								 o_dest_utm=null,
								 o_start_time=null,
								 o_path_wgs=null,
								 o_path_utm=null where id=".$_POST['id'].";";
		
		$result = $conn->query($sql);
		if($result==false)
		{
			$return["error"]=4;
			$return["error_msg"]="Query Fail:".$conn->error;	
		}
		else
		{
			$return["result"]="update_success";
		}
		
	}
	
	///////////////req 11
	else if($_POST["req"]==11)
	{
		$dis=$_POST["dis"];	
		$sql = "select astext(o_path_utm) from users where id=41";
		$result = $conn->query($sql);
		$row = $result->fetch_row();
		$path=$row[0];
		
		$sql = "select astext(t_start_utm),astext(t_dest_utm) from users where id=58";
		$result = $conn->query($sql);
		$row = $result->fetch_row();
		$pt1=$row[0];
		$pt2=$row[1];
		$pti_1=st_dwithin_retn_points($path,$pt1,$dis);
		$pti_2=st_dwithin_retn_points($path,$pt2,$dis);
		$return["result"]=distance_of_intersect($pti_1,$pti_2,$path);
		$return["pt_1"]=$pti_1;
		$return["pt_2"]=$pti_2;
		$return["path"]=$path;
		
		
	}
	
print_r(json_encode($return));
}

else
{
$return["error"]=1;
$return["error_msg"]="no data received";
print_r(json_encode($return));
}





 ?>



